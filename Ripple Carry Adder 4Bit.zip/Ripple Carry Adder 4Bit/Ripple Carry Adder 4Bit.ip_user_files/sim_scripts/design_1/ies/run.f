-makelib ies_lib/xil_defaultlib \
  "../../../../Ripple Carry Adder 4Bit.gen/sources_1/bd/design_1/sim/design_1.v" \
-endlib
-makelib ies_lib/xil_defaultlib \
  glbl.v
-endlib

