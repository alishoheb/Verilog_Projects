//Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
//Date        : Mon Nov  9 19:46:51 2026
//Host        : DESKTOP-M777NEE running 64-bit major release  (build 9200)
//Command     : generate_target design_1.bd
//Design      : design_1
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "design_1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_1,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=12,numReposBlks=12,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=0,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "design_1.hwdef" *) 
module design_1
   (a,
    b,
    cin_0,
    cout_0,
    s_0,
    s_1,
    s_2,
    s_3);
  input [3:0]a;
  input [3:0]b;
  input cin_0;
  output cout_0;
  output s_0;
  output s_1;
  output s_2;
  output s_3;

  wire [3:0]a_1;
  wire [3:0]b_1;
  wire cin_0_1;
  wire fulladder_0_cout;
  wire fulladder_0_s;
  wire fulladder_1_cout;
  wire fulladder_1_s;
  wire fulladder_2_cout;
  wire fulladder_2_s;
  wire fulladder_3_cout;
  wire fulladder_3_s;
  wire [0:0]xlslice_0_Dout;
  wire [0:0]xlslice_1_Dout;
  wire [0:0]xlslice_2_Dout;
  wire [0:0]xlslice_3_Dout;
  wire [0:0]xlslice_4_Dout;
  wire [0:0]xlslice_5_Dout;
  wire [0:0]xlslice_6_Dout;
  wire [0:0]xlslice_7_Dout;

  assign a_1 = a[3:0];
  assign b_1 = b[3:0];
  assign cin_0_1 = cin_0;
  assign cout_0 = fulladder_0_cout;
  assign s_0 = fulladder_2_s;
  assign s_1 = fulladder_1_s;
  assign s_2 = fulladder_3_s;
  assign s_3 = fulladder_0_s;
  design_1_fulladder_0_0 fulladder_0
       (.a(xlslice_0_Dout),
        .b(xlslice_7_Dout),
        .cin(fulladder_3_cout),
        .cout(fulladder_0_cout),
        .s(fulladder_0_s));
  design_1_fulladder_0_1 fulladder_1
       (.a(xlslice_1_Dout),
        .b(xlslice_6_Dout),
        .cin(fulladder_2_cout),
        .cout(fulladder_1_cout),
        .s(fulladder_1_s));
  design_1_fulladder_0_2 fulladder_2
       (.a(xlslice_2_Dout),
        .b(xlslice_5_Dout),
        .cin(cin_0_1),
        .cout(fulladder_2_cout),
        .s(fulladder_2_s));
  design_1_fulladder_0_3 fulladder_3
       (.a(xlslice_3_Dout),
        .b(xlslice_4_Dout),
        .cin(fulladder_1_cout),
        .cout(fulladder_3_cout),
        .s(fulladder_3_s));
  design_1_xlslice_0_0 xlslice_0
       (.Din(a_1),
        .Dout(xlslice_0_Dout));
  design_1_xlslice_0_1 xlslice_1
       (.Din(a_1),
        .Dout(xlslice_1_Dout));
  design_1_xlslice_0_2 xlslice_2
       (.Din(a_1),
        .Dout(xlslice_2_Dout));
  design_1_xlslice_0_3 xlslice_3
       (.Din(a_1),
        .Dout(xlslice_3_Dout));
  design_1_xlslice_0_4 xlslice_4
       (.Din(b_1),
        .Dout(xlslice_4_Dout));
  design_1_xlslice_0_5 xlslice_5
       (.Din(b_1),
        .Dout(xlslice_5_Dout));
  design_1_xlslice_0_6 xlslice_6
       (.Din(b_1),
        .Dout(xlslice_6_Dout));
  design_1_xlslice_0_7 xlslice_7
       (.Din(b_1),
        .Dout(xlslice_7_Dout));
endmodule
