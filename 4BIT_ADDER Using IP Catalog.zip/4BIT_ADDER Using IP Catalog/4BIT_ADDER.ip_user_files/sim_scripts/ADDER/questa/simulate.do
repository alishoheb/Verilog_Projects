onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib ADDER_opt

do {wave.do}

view wave
view structure
view signals

do {ADDER.udo}

run -all

quit -force
