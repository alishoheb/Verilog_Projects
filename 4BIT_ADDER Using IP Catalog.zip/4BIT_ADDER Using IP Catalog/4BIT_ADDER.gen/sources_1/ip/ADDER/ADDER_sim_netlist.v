// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Nov  6 22:50:40 2026
// Host        : DESKTOP-M777NEE running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/My_Designs/4BIT_ADDER/4BIT_ADDER.gen/sources_1/ip/ADDER/ADDER_sim_netlist.v
// Design      : ADDER
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "ADDER,c_addsub_v12_0_14,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "c_addsub_v12_0_14,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module ADDER
   (A,
    B,
    CLK,
    C_OUT,
    S);
  (* x_interface_info = "xilinx.com:signal:data:1.0 a_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME a_intf, LAYERED_METADATA undef" *) input [3:0]A;
  (* x_interface_info = "xilinx.com:signal:data:1.0 b_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME b_intf, LAYERED_METADATA undef" *) input [3:0]B;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk_intf CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk_intf, ASSOCIATED_BUSIF s_intf:c_out_intf:sinit_intf:sset_intf:bypass_intf:c_in_intf:add_intf:b_intf:a_intf, ASSOCIATED_RESET SCLR, ASSOCIATED_CLKEN CE, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.000, INSERT_VIP 0" *) input CLK;
  (* x_interface_info = "xilinx.com:signal:data:1.0 c_out_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME c_out_intf, LAYERED_METADATA undef" *) output C_OUT;
  (* x_interface_info = "xilinx.com:signal:data:1.0 s_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME s_intf, LAYERED_METADATA undef" *) output [3:0]S;

  wire [3:0]A;
  wire [3:0]B;
  wire CLK;
  wire C_OUT;
  wire [3:0]S;

  (* C_AINIT_VAL = "0" *) 
  (* C_BORROW_LOW = "1" *) 
  (* C_CE_OVERRIDES_BYPASS = "1" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "0" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_SINIT = "0" *) 
  (* C_HAS_SSET = "0" *) 
  (* C_IMPLEMENTATION = "0" *) 
  (* C_SCLR_OVERRIDES_SSET = "1" *) 
  (* C_SINIT_VAL = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* c_a_type = "1" *) 
  (* c_a_width = "4" *) 
  (* c_add_mode = "0" *) 
  (* c_b_constant = "0" *) 
  (* c_b_type = "1" *) 
  (* c_b_value = "0000" *) 
  (* c_b_width = "4" *) 
  (* c_bypass_low = "0" *) 
  (* c_has_bypass = "0" *) 
  (* c_has_c_in = "0" *) 
  (* c_has_c_out = "1" *) 
  (* c_latency = "1" *) 
  (* c_out_width = "4" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  ADDER_c_addsub_v12_0_14 U0
       (.A(A),
        .ADD(1'b1),
        .B(B),
        .BYPASS(1'b0),
        .CE(1'b1),
        .CLK(CLK),
        .C_IN(1'b0),
        .C_OUT(C_OUT),
        .S(S),
        .SCLR(1'b0),
        .SINIT(1'b0),
        .SSET(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
R+TTV2BAhe9Ek8IveLCAIK+vyB2qa4TorazWyGCbrxCKkVhTBvAD6RqPeP/JqtRuh2zDPzraR9rT
gUyNSWD83A==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
XM2mYTm+gCT0AhW4S5p7IlzH34WHm/fa2tLSENK5xQp44huwLBqk+dBcYbe4GM+6wqA3pzoUNE9T
SluI3P6DpsOt14ispiaJSciB+VdlU+Q0e63sKyfq++TGO3CTW5OhLIxojUbYrTbdY4WbGkk4yG0Y
qGwauBBx1uBueCA2GC4=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
M9U+BjMD5E96pT2zTDB1OSiHn8IS+G+aDNa3MIF/jeClLSPAOJwufjuzRcyAtwx0354Pb7AaFOwR
6CcoWPQM1dcUC6avyG/0PRrtZP/KpXS3/9PiWsaFHPYVLfqBMCUDoraXwfpfMxmOy8hD0iI6TtWc
j1xJUXVsbv+kqOeTUloYmwdRx/8cs46FvZfnFpiZXMFMsTsT9zvmCyNxiZefgFKT064BWsCkg2fa
W2IXperFJQzpE9mXVwGSjl6xDUp55esPyEPcDI4xy0T+q2KtBQj2Qn2DJRZ8DKAvjXNQmo/tbweh
l+RGgbFge035kxDZ/t5pFweR/SYowAMdG2yOwA==

`pragma protect key_keyowner="ATRENTA", key_keyname="ATR-SG-2015-RSA-3", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
absLoVdCG0/WeiZ9M4NtAUjz+XnLze4vahkoVw40DL65GHoB/ikdBh+LyLQ7V3LckxaJp7Ihe1ow
2yXZZfuygvynBc+n/CI1EDwjo64cUTgVLg6gqySahs3D5Xkp8kFBBxARQmdoErJqqhefej6SXrxx
13OxNfq4vRGx7YG4l2M61gUhVtUX9poQdq5dxitmrLXD1kpdnUsj/YIpVBaLv/TBn9G44WiyRNIK
ojx9q2JyYKiWBfcBh+fpJV9PudrBUPMu8kvWsRizFr+r8Ya09D3o9iJUZ6FWOBiFsidvZNgmp1u/
nv56cp+qpaTesLtwmKiZbrhQtq6YXQvzPpDQXQ==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
t2oJ825g01R4DfbjT3g+VDPmL9PAyVC2t8Ozl94Xb2xucD77bNiPcvutyZFkA0lqWfRMp8Z3kkTE
OOo/FpGS3c1SP04/jMKLZD9E7DL6iVBRfxa3itPHxsSD0RAP4yPHw3yCiIsmB0q25x8+so3h/QOv
DKZh98m5ku9UnG+pY6c=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
koDeaCPE+GNu9rMKu+nnX8UvNKbOa7mKCRwRUXCmZNo0yL7JuxnKQiStr89+6Ws9bOIbY8P6XKLC
WoSokcQl2MIZuh7gUJ+LQSPTB9HIkHPuGGPibAaiYY3e/6TBvv0+QG5gTvuf18Nz0UQyxRzNBFY7
2e0fNw+zoh4XJubbVaqqBBqTNyIM/naqx2G+DBhvJF/RlcpsJUe2eVt+uttis5ukRD1ndenp7rvA
+Ub6MDtoxunfFJsXEQ8QZkuZiT5XfcmJdkquGywSafJqKksYNJZpGleQnak/ePqKq8cYIbfpqOo1
MlqTFX2khe/WU/cqsW+5jXmRAgWueTOvg5hW2A==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
wZaMVki09KtetQFaQKbOEpc8bkgxHSc8zyuzh+dwZ44uN2hbx3K7ITnC8dDkn3EMZGwk7C0u4eBt
eru14n5jQ1LfuUg4cKuwRNAgFxc7GaymqPYSRK9OQZHWZ+w6Alh4X9YWb6UVcsv4sCJA8YT9QeZ2
8PJYA3L+OY2t8Dcx3JcdLeVgMWDrP/zfpXyfMdPpwgBSSCqJHFsYdlG06onoQq2DDJ/SpC0W2oHU
JJAOTss7Cf3giWx2XTrorU5k4KbClTaEv4QAsogatkMf+oa9OfJQg5b7OUNbNqSzTV2IvRXtKIBC
N3mFkAtau93JXZzbow8bF+Y708RmUyIR5AX9og==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2020_08", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
gidhQdKtgCKZpycO58SKONz/x64JxoYiDvm7CY7FhAgR8N3zqVR49qh/d9ImLGjAjXhz9ISSvhiE
1TpzIsqbVIoSEHhHCsw8fW3eNfjSKG9+5c0qMghoZBwnf9txWcso6wczPV8wSYfFgOnId+/H4w2u
MtSdrp2j2HeGCN7hmduXDeRIcLF+ekxNNZVk0wscD3yxYdFDWscebLgM1N+Cx8uwWvloVVe1fNSl
IBecuxue/tBnCdqw10D1fC8gGorhdNUhO2bTYqZL/+voIIAXkux7Z0BGx6B2uSJYuZ0j2LS23yyk
r0QDrL3YOpbEPBbFhTy9LQz59rkITBRhVeBqVg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Lv7TtlI9EkMH+4ifu40NSGcF5VLP+fQr0uBXzvHjgpvggoEPEBlbTyXFtewlIbLNuHO4GjqSxFa3
oGjcKGgjJ4JKEHh9NZ/42sDCCnN1TS1zrfhPhpg3aJ3aGsOq5GxB6oAuNGvsTC7HgKk9lvgZfAiC
9ubfhd8fCUCrbS2jYuGLkpNxtwRxEbxLfMa6l2yusSJt8g6sfH0aGGBJWZjKnUZ1SyA1DmzZW3ox
o1AE17uwesEX5+JGPaqlsN+jLpbHhpv24GF4NS806LjJrXOO9qXbZScc78Z/R2xMBhLYAC0AHR8o
o8hlz9kYq3NSGSCdEMOcxNjVxDMYBrdZ+Lc+ag==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 2432)
`pragma protect data_block
EGz3iDKnlyx7uDYf90Ip6nQ4jBe+LJuWPBUJBLt2pJosPbjeFSPtAFnYq/+WxxA1a3VgmlkYdy11
xFxVGw7NO1b9X8ombChbS5aiLrn/xt3uXEkbB23n4jwllCNiGf8EkWiRwFA6zP2GOnDyjS+bjl4T
5zIITPTSrBECv33EK0FzFV2qSqi+IVmbzQKBR/UspCh1Ktwdft1EMhSk2FuS+VOU8BdqupQShPun
u+rgNyyceEJF6NWdMxw2m8nKXaqM7u88m2AZixBc7FRnZgdwZgW6c8MyHvZT47KZtFNEe+0+2zRh
ZCz2AhF6/S77t8+A0x9OE8ZZ0PwSLFRZIeOocItR1Tvv3m2FbnN37UVC01IgSKFX4HVUx4BcfWnF
m1bWtAsayrln87jNHthGNeZtTVCWUdW6a0mXyW1UMabZz4DiLu4xJKMsRjrorri9acpDW30jrg8R
7rr+c4rfZqq8t4BKca5Wg0+4EwvfpAsCw0Th7MGsNDzDIYM3eBhCZlINnjXX6xku9mnu0JC+z0e3
2Jx06fF0uGa+YekwZlW/ZI4LqnV05/CE9QfELhdlcHTTmXWPYP7cKlF4zDHl5dkzX1SKiTFDrD/D
ixO7K/KziNkRKPQkdOCSiewToCC8VJF6R7ldh+JB7zaYuaolh5hrzZ0N7WaS5q0Xixp4m9oNVWj2
4O2Oi6LuwLM9iT1NGqnfnFLca6m6xj6MK3kdwKsmZM5rwhr+0HNxgX0xwUj52fE932AwpJudN8MQ
u08BNfiHQtXSkzDRSkUyCGzXpqroUev6D1buRbHXVfMCIxMWHpFGaYtMQQ6r1F3Pway4ekY6gF9G
nc7E8HBTCvKRSN9Sg2zDh2kioRnFDeotr92d6/7Fu4zDRGDQpGxI8eSTwpUJ9X78ClDOAKRAs3WK
KmXmmKPrTrHafiQYfGPTULPq5g+L9W/ijJLAST5mycDvTHJ5ZxdrIK9+tXiSgyfnsGbem4dakaoF
DSi6zah/8iXbwXa5XeaZ1UR6Mkx6OHb76kuMr8eZdMXkQ18lUuFxRqjzrVgc62cjoLxDeGB9JoIm
mOEJ8crQjsORTFg03myT57Mzvbr6ltYRmwVgzWZRGlMmwnh8t6hduN3Pj9zdfE1jZluC3FY2WllX
V19TvNbzqxFJDgIbj9Yybyl6CtWFhz24WVXTTeBq9Lc7kBc4hZ9HqAlAo8TBmJsvP5tmDu989FR4
1tKw6CguHMQBVkeb3UVwo0aBUywY0AbIh19aNvMBZrWKOuqcyN9qN8hmDg/ciVWEtH53OxxAjZEF
OX/GHf0k5NfQNIPOQ4UQ+j/kAzlTjyVwiNdE+MKzLbG4C7LfNvrLkOB97wNUsNz/sPn7SV0ydueJ
lshA1gXKwAXChbtGpxB9ACtMcm+o1GiNNoU/rK9ckujyXbJfPW4+nk48CJS1tMl+rG5l/yN3ziOE
O13W3fu7T8wWk4J9ev4vQOSqveKdVqPWolKuKcHP3cyMvpyDW6UEE1Goo8Pcb21QNLc4HmbuyZ45
cR7bhFdIyf01ylPOkOXJV9g9f4YrBWnJGFHpy3v7oeq2E9K41kCEjX6dMS++O/NV2UXpG8BJYc9c
6IQFSvvuBjaYaMZSC3YDvqzqe6TRiFo68vcp8seIOvrJI+/n3qofopn4kqOGC9/jFCcH3dCLFmLo
mgckA5r3dKtIDFBZnp2Zx8uMZEXR78HHCYC8XnuMzLXCeD1hKQi5qrl3S8e8FA5t+siUIiJLDM/E
za6WIEAuSurlRnG1qABJohowZ95NYnTJdzLly1PUQaaOqvNd+Hj/7nxw9kcqPPrEST1bMqaylc4G
4Dy2Pi6YQFcWQjTed8tLIB8V4LpDgSSKEGO45wGkokXGwX9tMtDfzpwBo2wlbncRAXIlKFhcCgNX
f0PJHXlpu4Yz1Mxkfk7CeldfYQzY3E+eFEJCnWLEDsz0Y0JCd2inIVorzrNwBtBT7SEhMPqhSjz3
5Ymjkl8PskTPzGJ23eWNvQIv7KfvB9WblqUgvzpq8N9JkaF48qr+XdfgULiN2Sjtd98lJprmeJnM
vdm+huJEM4sCOiHe7fKY1lhyQxluQIP/wmr5HCMXQ0peCgeFXUY3jURGoAkoGBJ18SQONA25jbVy
E0lBkYjGmIUpKPLTxHWwIBgoEj8wCanlBj/NQQ43ENz6ZouwGaaj0HX9tynx3N43g5yQKsWDS1uG
Il9klEeuKSoU74BrFZnUL76k0HHE5o7N3lpE14C3KLLXRXxXYjPMYkWljhWfc4udMvm5+2ssmsgH
yl0GInTC995pVdJnMlMbI4ufLmC5cz7hDIgd3QpZB8Ba3fVBdTJHrbPpBcXFjBJz4u4Wq7AIFOnT
UWD0CcBgnQplTYM5Cwey7Ux61o0gPSf5ptVAOHbuO2xS8yjYJxWgbEKN/3ToiMcU5DQ9XdrK+WMl
OlDwJzx66DOm79yfv1MZ1bsR9p4vpc2OW+nQJTFTNKbAEImyPVVbdYJBbq6dSLmz7cy94vp/Xp41
crpzO6G+m1R5WSdl4ZidS7OEJB+SUnX+G12br0VRNKhslVmVB7mMzn46fGS8zE71Zyxpy2Bf1rTD
aNsD73DGdhTHDLxAIbTPhFxzLdfTO+MhZip6ZungjHY0ShRP4DcCMwISxtdMsQSCypnZw8e7jLdh
gerpFRbRSKzC5ZiRJ7uvd3y5kSW/aiTcJMmcyGP70f23fSe6OraD5bnZWZrrTlkKPmLxVlnNYpiF
e7EGuhG07JbmBrDFIqEtziZYR3ZsAkl8F+qJqPSMn97yy8ui/In8SjYnbR5OCXtrhL5U/KRQ7B6M
6Db60Bmj5+fjv7IsWnkohGZ66lRBhqH/U/iL/QEYvkIdQxFPALDgKgFCDP4+65PvP7hDwwUfGJ7f
pNAcdrdlaDm+GFAOR1SPcjQF2J7dwZSkS8dgW2U29Nd1GioNh4rR4tK8G/PJTOjhQi61Fk67JOEO
hWHuT+DBgl4Qwi80ZUN/r/8GZuQPBQceVD6YlVqiDRuAnfJdFVSu1yi4nM905AZiko7C776TQoEM
+jRqTm9tWgWq6s8WUi1L/5PeSHbvVK8zoUjVOExwWXQpxfqc0ROgbsKsdFKCe6PyqFpMNh7MXW5M
2ybsRfcTu7DRVLn2d75mMtLNqMq+ZtM2d4PBb1IfUhac8fTjt/MDeb/5uil673k4odruIPquUkZy
VM4oircKUJFqzaDjBR5Bi0OwSm+C29PXUlTY5EIT9E3x6po45S4=
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
R+TTV2BAhe9Ek8IveLCAIK+vyB2qa4TorazWyGCbrxCKkVhTBvAD6RqPeP/JqtRuh2zDPzraR9rT
gUyNSWD83A==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
XM2mYTm+gCT0AhW4S5p7IlzH34WHm/fa2tLSENK5xQp44huwLBqk+dBcYbe4GM+6wqA3pzoUNE9T
SluI3P6DpsOt14ispiaJSciB+VdlU+Q0e63sKyfq++TGO3CTW5OhLIxojUbYrTbdY4WbGkk4yG0Y
qGwauBBx1uBueCA2GC4=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
M9U+BjMD5E96pT2zTDB1OSiHn8IS+G+aDNa3MIF/jeClLSPAOJwufjuzRcyAtwx0354Pb7AaFOwR
6CcoWPQM1dcUC6avyG/0PRrtZP/KpXS3/9PiWsaFHPYVLfqBMCUDoraXwfpfMxmOy8hD0iI6TtWc
j1xJUXVsbv+kqOeTUloYmwdRx/8cs46FvZfnFpiZXMFMsTsT9zvmCyNxiZefgFKT064BWsCkg2fa
W2IXperFJQzpE9mXVwGSjl6xDUp55esPyEPcDI4xy0T+q2KtBQj2Qn2DJRZ8DKAvjXNQmo/tbweh
l+RGgbFge035kxDZ/t5pFweR/SYowAMdG2yOwA==

`pragma protect key_keyowner="ATRENTA", key_keyname="ATR-SG-2015-RSA-3", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
absLoVdCG0/WeiZ9M4NtAUjz+XnLze4vahkoVw40DL65GHoB/ikdBh+LyLQ7V3LckxaJp7Ihe1ow
2yXZZfuygvynBc+n/CI1EDwjo64cUTgVLg6gqySahs3D5Xkp8kFBBxARQmdoErJqqhefej6SXrxx
13OxNfq4vRGx7YG4l2M61gUhVtUX9poQdq5dxitmrLXD1kpdnUsj/YIpVBaLv/TBn9G44WiyRNIK
ojx9q2JyYKiWBfcBh+fpJV9PudrBUPMu8kvWsRizFr+r8Ya09D3o9iJUZ6FWOBiFsidvZNgmp1u/
nv56cp+qpaTesLtwmKiZbrhQtq6YXQvzPpDQXQ==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
t2oJ825g01R4DfbjT3g+VDPmL9PAyVC2t8Ozl94Xb2xucD77bNiPcvutyZFkA0lqWfRMp8Z3kkTE
OOo/FpGS3c1SP04/jMKLZD9E7DL6iVBRfxa3itPHxsSD0RAP4yPHw3yCiIsmB0q25x8+so3h/QOv
DKZh98m5ku9UnG+pY6c=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
koDeaCPE+GNu9rMKu+nnX8UvNKbOa7mKCRwRUXCmZNo0yL7JuxnKQiStr89+6Ws9bOIbY8P6XKLC
WoSokcQl2MIZuh7gUJ+LQSPTB9HIkHPuGGPibAaiYY3e/6TBvv0+QG5gTvuf18Nz0UQyxRzNBFY7
2e0fNw+zoh4XJubbVaqqBBqTNyIM/naqx2G+DBhvJF/RlcpsJUe2eVt+uttis5ukRD1ndenp7rvA
+Ub6MDtoxunfFJsXEQ8QZkuZiT5XfcmJdkquGywSafJqKksYNJZpGleQnak/ePqKq8cYIbfpqOo1
MlqTFX2khe/WU/cqsW+5jXmRAgWueTOvg5hW2A==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
wZaMVki09KtetQFaQKbOEpc8bkgxHSc8zyuzh+dwZ44uN2hbx3K7ITnC8dDkn3EMZGwk7C0u4eBt
eru14n5jQ1LfuUg4cKuwRNAgFxc7GaymqPYSRK9OQZHWZ+w6Alh4X9YWb6UVcsv4sCJA8YT9QeZ2
8PJYA3L+OY2t8Dcx3JcdLeVgMWDrP/zfpXyfMdPpwgBSSCqJHFsYdlG06onoQq2DDJ/SpC0W2oHU
JJAOTss7Cf3giWx2XTrorU5k4KbClTaEv4QAsogatkMf+oa9OfJQg5b7OUNbNqSzTV2IvRXtKIBC
N3mFkAtau93JXZzbow8bF+Y708RmUyIR5AX9og==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2020_08", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
gidhQdKtgCKZpycO58SKONz/x64JxoYiDvm7CY7FhAgR8N3zqVR49qh/d9ImLGjAjXhz9ISSvhiE
1TpzIsqbVIoSEHhHCsw8fW3eNfjSKG9+5c0qMghoZBwnf9txWcso6wczPV8wSYfFgOnId+/H4w2u
MtSdrp2j2HeGCN7hmduXDeRIcLF+ekxNNZVk0wscD3yxYdFDWscebLgM1N+Cx8uwWvloVVe1fNSl
IBecuxue/tBnCdqw10D1fC8gGorhdNUhO2bTYqZL/+voIIAXkux7Z0BGx6B2uSJYuZ0j2LS23yyk
r0QDrL3YOpbEPBbFhTy9LQz59rkITBRhVeBqVg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Lv7TtlI9EkMH+4ifu40NSGcF5VLP+fQr0uBXzvHjgpvggoEPEBlbTyXFtewlIbLNuHO4GjqSxFa3
oGjcKGgjJ4JKEHh9NZ/42sDCCnN1TS1zrfhPhpg3aJ3aGsOq5GxB6oAuNGvsTC7HgKk9lvgZfAiC
9ubfhd8fCUCrbS2jYuGLkpNxtwRxEbxLfMa6l2yusSJt8g6sfH0aGGBJWZjKnUZ1SyA1DmzZW3ox
o1AE17uwesEX5+JGPaqlsN+jLpbHhpv24GF4NS806LjJrXOO9qXbZScc78Z/R2xMBhLYAC0AHR8o
o8hlz9kYq3NSGSCdEMOcxNjVxDMYBrdZ+Lc+ag==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
aehLeeRkvD7Y1U0JRsSBYNhzeaodfOd/DjucRtcMU6ObMVApj7GP3zDpP3Q6ZQOsIFQnJOt3+ulP
7AmCik5opdqRJqNIY0Ww1CWBaXt4kkDMQm97hwqtVGTJ0gW4ATGhm1z5P1cI3VT5BSgfVJzooXmU
EaJXgIxw1JQ0qPYZH/fsp1P1KtCWNWObh3a0Gv67eStKcltPLKTMjXVnyYki+oXoHfGbClsZCUHg
s0u465sSbW1mfNYZsVsSHxkVKBHp7W3DJyY4K43jns/GJedhCTwOrA+VqhNOF4goGeibG13BNJxZ
HoY2sduVeUnheYrwHqZjyJaGZi03M/g3kDximA==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
X20ffTDE1VpCV6HDcyWb6mQVDJTitjUtG9UXAzpHO2m+3Yc9dcHvhZwbcqv6rg0q9t7cutgpgfll
72k339/c5oVpvhxp1M8PKQI2Amla46v9wLyPjXJjZJoEouKs6GgPwFcHxnIZprQuNqmhiM4IXo2M
zUAAaYQguIcY1uHAzuepgDckYw5rmeM1J05wLWQPR7e/3UfKGqFZ0TSYtzJbAmslgHRvzs0CUKC1
s68oZ7XpY/XiBifunFhJb218YdWONFhBLKZq9/dxkLlC46zHv620ZhL2ohKfIpe6jdseLOcDc8Mk
9+6j8N2MKDTWNjBsITnDvbWv34l7//l7KqPu0A==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 5968)
`pragma protect data_block
EGz3iDKnlyx7uDYf90Ip6qmlfj4o9SUFaTZm9qFAFrY6dFlwBXrKDVq4jKDfc1jZbZXr+lU8IAbc
MdTRBH1AtPn+mGPZ8a1i7AcWBqUIttYL58RySBBY2DVuLXZLHmSjwf4odCFRmYx2NT4DhxgoTByM
lZF0mJZ2xZk6E2GnwFLbNYTjJt+FH+ekOURJYYX8nnyrF+i9/p4JTp8T8kuKOq6qgcPzcNd1LMWP
KsO5+84ADFwFxbuBLtRU3D2iHRgi3tGPK/GUMdQ9XZvynV68aLVMOUNE5RPY8XU0kdAWCB9joP5W
Nir0is+Nbv53YHOH4+VqbZIIR6kky5TIpxhCmcJO7qrUSYnF5/KlYhlOr3QlFYyrRMSNzlwwG+wD
mU1ENUgdDVUXhMwqNG5tbbzkdImpJaw0zTq+XiqOrLzU+RBb050P9m35Q/PtDhvUTtbccXqs7Lq3
rajWR0ZExtg7pf5Dmo8wlA4MarMHoCLde8Au8x4gKuEWT3gs2mUff11seWJg9O5FPcGlpJR3Jlrq
cELwNON49ZriUH4dA9mwRWYTqdyjWeeJk2ECQ6Tw58ylfPBrv1cTfnACHOyRs0XivixzX/eC+6zt
0WnR/l4XkXk2B5oP3LsdkehEno25lcsl5FSzW6FIxRA9cxFX67Stx/cZrTYU6u/ZU9nTY/nfeLyW
jUGCR8uJ++lzB+IHZlPkpKOghoxala2FuWZvtiY1608fDu5dIaJSfIgBEHIcduOy8lhWldFiDeZf
TZXFgqitxulZ3Vw8yA1pGtO5ZsuJD0WcHfcI/7z6KKpx9LecOFTIfJMPqRH3oRdaoFESZWghc6im
ow/ZTiXNFnAIEOIKdrlw5egjnB/dmdCdF+BoH+qeVn0a7MBMWyrQ9tFWiafmrEeA+ujsfMYqe3xZ
0tByb/a0zfIaHZzXFxRIzYbj4gMvyNS4tUDtJEYxGBSr4Qyq8aGHejMN7fGDb5LOsmEKyGzEUAXV
awz/FX2EJKR1uqr0mtiCej6sk9k4SMCqUTOILsoP9PZ8ZowbBg4FZhSVV73PLb5cxLcLIWZqeMD2
h59sBuiHlfaubJ92ToBiuuJiP2Iz4DLC1vykJNG9Ueuq92pNt99uwVJTsjadsIrbCI3T/uDMrXKa
8LQq1NsVsprzjfO6B2/bMWqLMiOVOhELvRyWDMQvFOoizIjANtxX4z3Ei6mpF2BFja7CRjMoWdqg
yddXePW2F5Ri/R6OA5mcGZE8pcVHfLcGHWaOKziIxwhTmsnv53dmUGLYpkUfr7ktog10tDfQQWyv
UG63fceGUgD9We1xKUZAXD1tOhMvjGIkNKjpGnyYvKolpFI1NZYGyaCUUvFh4L3ddcIhu82K+5ge
WP1d3zdEOa+sN8gTCS247iwhfvChIXwFACdG58Yr8Ba8iAklnHaDgXqyVesjykIcBtS9bNiTKd8V
O2x1TjNZNsAuKthGlBQce2sV81INykRhoCjaX9MEDzf+zNUTvVwKLYqfaTH9Auup4lUCYHjazmfz
k3SGf1grNJQ6bNHaW7MPo8KOvpeeu228IS76+EccvXRJU8Cp0l7Jyizfmz2aocLC19j3R8DyE2HR
5SgKUL6czU64Ucg4ksO25pCg8RouNcHV8HeJjnBIqFcn9qsOUhN3/a2ZtiR+2URMoIXIgCtTJGV2
RICg7bjzY6QR+q0X0c4R0IuA4ggMvoEeUJaBDLJV6I6DE/XnWxWrNIh9bEvv6cObKg9qGT0K1X0Z
wixw9uyLXlWxD4J9J7Egb6KGuYiBgccmOA+SQLcZ8Cxd5BYF0iyn4W9P6zvP1EhavLqk62Ugh/5O
2Az7a0xfYOXTBSfw8e7jaegfA3NH2g4xAf3uf8WcYe5SI2+fDL/Xob3L5us0whOTK4VFMimKdfmV
PLkww9/lO3Z7wFWsDlogJ9s6RlMGhhqxQEozwSMtRh362ClHFeMdWK9ltalSM6HOHhJ04OHjrtHo
Z1xr9MbqgDOWqtVyM+ccCxYU8FnDskdTRI3uSFUmBJH7te6wQs/LQpo/cvHDFa3iNCnCSADtUvDL
i1M9P4i9tU/2oKkyRRfC8ANT2YRDZ3o7nRdJ21tlRZq7JRac2/g/0eridwD60RkKxTnIg48mD5W9
hK/5hNp6lVrBkoE3qvMfbx/oHXFfiMmLICnfI9aDdMGOYkKjy8aiElIgEEDviM+WTcBWLKUQ9OOx
cX3FxxQQVNZ0Ui6WLpetAp+mF0+vc3c6m/sFkfQozRcLHwyd7Jn8sem62TeE3uv1x0BuIDmmWzii
aE2mCK4LUETYP2g+LSZsIDs9RgxH4C7GqiX3/+dN+qy7gsKokVNIxwzD1eY53FDRzwJ1+kTvOwyh
GZ1IkFNe0qAPxolzIh5RMFzHBhdhEXH6Lz29zwtBPZX2pVOstmR+I6SiRAcp905in3VPE4cAbXpL
usM5SpPl+sxkpjHsAxzQBqbGlVIcwln8/GFzmvZrJ/U6CBhee/IFYF62yPyYaUlLV1GmwBuFaLVb
zLnAi8hqWie2AhgsiArTRPJ30D9+aTYFgMtSGvGl1U2YQ31F6n4zXsH/jIZNLn2VJApJAhED7bFp
MmPJ0UPU77GoIDRyK9ZJGu7XIUPbhJAt+snl8M8htyvkGQgh2tLDOn7tdG11i6wp2i+nP4f6wOhJ
pZ3UQmTV2Sdb11ENbVneA+fT8sOQAck2JHil77X6Gqsmug4Y2ravpm+UeXNGZqYU0D2ZiHa7mX9R
8YpDIAt7PbF07GdhKetlwRuEC6iiH9b1NOOtMhrXPi005BbFZY6ltllEt2uFWDbT23XQ0V3BuLdR
B23R/2zQYzrYbe4CnOkS8jAZ8egFrN/AlwGxyXkkLy/THFKZOqX2mrWOoo3nn+mGXJIQ77otu8z6
gqEXox7V/6ruV042hXo7Eskm4O4w2j8d07RrzmZb7HaVGq1B8SAxpFTtKX69vvdbCF7UnN0xxST4
SICLhWWbw64fGssBInyS3psjgNeQYaKVXBCC6XFPf//b4QMNNzupKN2nG2QIT1pvLSgSc2RZuZoe
qbQcpatZRjwkUbnso4InufNDTog7WdbcyCP4iNfN7Y9aY75pkXy3aeBYo3cnZe/H2BgKa2YzzvtS
Q/CBCq3DPrPgY9WmCvBLGhdvQUcFxAFPnthjhPabVUATv4ULsimOUnj6olwhsbglHt/LtauWtu9F
cA+PGUhxapUa+pqZJM+gIBbvmrYxqeLDhfBGUhjYAZCMCxjd2bmh4sFJmnGzEnWbY/VVkgTDdsj4
A5+SzrCQA/gICl6l8NoC/Kx2Zk5j+XbeH2pGZaIFozpPwDN6LuJq52J9R8NDF+9IGCZR4w5IJ0lO
rbC+Phk16uT5NhU2B9aGh+EY18Scs/LRbVkGYYOoKQiKd1WJXZM8u5529nVeWKJNlir+1UvUS939
CJvOlIpZLpH8EB7uSufL1OTv7czY/5UG2QU8cKasS8XKf/fZnC2lzzc155ct2ZWG9cwreOX3DlkB
RZ5XzGA3SM6NJxaJfYgZizTKTZYt+zFeg+YS+fD7oqrQFw1JMaDtKbwHnv2sLAEpXLmmONwOPuPX
8PBqwRkO1Oib8nNSr7JzGVJhlVuMrNq1jyAE0RTfqjkI8Olo0f39bJJC0YuA95z4e+zuY0ANWAt1
YwXYt6iBlUMpH2gDYKiF91RQhjvHNBiTx7CPqq+/IVXBT5H4wWQXM1G0HvoTXru87wb/ZtvaR/Fq
q/YMeSAhlK27V06QkACkeG0WhQ66k2Yp2L/iavae/yK6eZkHvleZrMIOCdkaZi70Lhk4YE8vYDdq
O592aKfnGoY6olSOF88EYEGGHshy2N4VKsEcJv3ApAFDWO+Y9NQ9b6m2k5d9WxpdSQzPxt3ndXcE
eQu9k138oKnGrpOZSH2+LFYKeWEaK106An/RTLkzNQEM2l8Ws0slUtIJeYeBXBRkeBahzemw6XB2
BMocdUvE8X/mHavoOLXjsofvCvrXBqcJ8c/osygZ8WZeNuS3ttVCUjQ0xYZv0oDbh1vBMgRB2lVI
w0ow3tYlMfBVo5628696TXhcmPjrCV1QcNb4ahWivPC1yDbKWxLeOiz0IhpWhzPp+pjD7XMr0Q7w
ozbGWCJejwNd3ZtE9ZW5L9VEzd59H13fP0bPjWt4gO/vzer/DZOjCmzG14y6TACuzOiMc+YrYu9u
llyeSrXXWMdnA3SOFV6y+zf4WkxTMpv+ZmQFzcIsFQBE/5JT0wfWkpplI/31g2iLSzStzPzkWIie
E8MXjKIJ6IAL9JXLAwTziVMSCQpZay++1pP62WapXr7SehAhZyc+BjDGsSqjPgWwVkafbUrSEvyH
bp7w8B4oysaxaHXXk2esML9LwVNynKD7o/UEIn4gVlltY4qpFrr6T6e3shcHfIwJ8MbYyEDyS+vo
ZDB3g3HjrFKT4piqA98KhKhXZup9J4Id3/I5tC6TdKl3xIYpc+9gVeDyCunJy9VUdK8TR60zv1Vy
XoCzoPJw2gQK5cXdPVlj1RMWlFNu3Etyb/CLDsuZylI1GVy7wiRiqORf37Ql4LpPTznWLuXd5lTf
FGWv/KPudzgAZHTKMMTugkm6zOn5eTR5UqbVQAZp+2nPZkoj9R2YZxKdPD2uJu11zRc2c3xqHDXh
NjyG9kF5nLboORMQylxCiWL3jEruqSTdCs1mVdB1MkFGEHiZj26TKPBt3lxcI+0roGZ4f9+hIHX4
x+3e5BzlG92OOrFK8aK5j9lstRHyRhwFGL1vWQHoSuvuqzCYVk8jNwQllh4VkZwSRb99ORVgmdTJ
FiI5w43JWlyAI0YNQPef9xlB5a9sFxJpF5X/Vh8LkxyyMt+JjE3r+S7sDcma/IQnbKW7/fVFTY2K
cVR3HuOTrS1tIZK+KSI8307kLhv0CbysydRJl6948DllXDb/Qfx2dG7Q98dmf7QkAmt9jUO//DRu
7EyF6hJ8IkzP6GUzmHL5NEvxSzOZcdHLsFYgHmwDUCDR860wk/u5f7HFRPT+TmSd+LQKX0zN9GEW
c4AhA4lhaLEE8DslVZGRiIXiWcr1TpM/zPKVFPc3obkFgUTyMVPTknVkCK1Dtf0Of/pRhsIkMpYd
gvFACzozih7NUeunD5KrQ6qaCRi5Fx4Wh+CYBsrWPdvuWsgznRzPUW87gdH14D7RlUuDvIkiTNva
fzzJgvug8QQWT/gNrjGzgeD7RbDdPa5AU0mDLLfDwDNYOsY/Ic7zhFZxa+jsj3iibqo174yC9gls
LP838MyQr8DpQerR0NPkFe7w3kdPK0jWf3IT7obUfmj78Vrf+SnFlzcFywfRwZ8ZISuvAzSrSvkW
9CtE+63/OVSBrBo2cwtFza8/kxnXC+5D6sIW59W4QJh0Cl0iBr+mRgkbldMXOJBa7pqGYIcAihOi
vtn2PcEHCJw9ek5xBxXc+trmfq+Tt4HY1GF/Lrl/FGHiFexYuX9DzRFrE+vZhvuiS0KN4TDq/4L+
qlMqVZeQDbOK+Ma/hUW0WHeH420ByZNUKAVTMzhDaeYTprD91ABLBP+vknqy/byhNhAELxV6qMCT
SQ8iYCwHKXMiYRxv+9Bmd7aZhx/Iiw2jG4siEY5pKGT4YwqKjeCx3Ls/2WSzaa2pKfHFH4T+hI0x
UgP7wUM4pBv2wW1WO+jvto4QyObB68/TDppIlkh1N8g9HjGjNpeQwIZIR2MX8Iv4yVS0cwxx3GR9
UJFAh4FjEOYM4f4IiRRAQ+DDsjZjHx5sRhtZnGyKzFe77B1Mb9nVx/Gl8PtIRS8SLRvswcujskHX
dywhnVoXLNIlC6xy+k+LrlMOQdJBGOWL6UcZacjmr9URoWhh71LuYgHfIIHnSxgKv/WdV3gmzl9S
FKQTO4fqU/9iJ+MvdbuVi39ePJK/7f/C9q531rbCSuoTQ/51ma10qEgGpSwn2VMiWFk92jZE0moR
U/g7cybFzt3Xtl54dLuo352wokmHZo7dr0xtRTX+0EA8BtcfDIS4wzceW1VijuqugaDnrcsFZCRG
3tZc7X07c2Cfs8D572O3K/fewaahEJuYEXWyHka2RYVuLkkkXA+vdLog+FdkGkhZFNXul3h4UE6/
g6wXKn9jY32+J+Tf4BOTomFLs+xsvi3R3Rb6gPyjbJEPVkCjVIEZzmCvJ6wS8vBycpTvyMhj1seY
W3JwL8l4XRk9lQqeaDmxe7JYTLtb4j7tBS7Z/7+ZRCGjPSrkC8LBeHtAwdE+KQS6Q2oidhiHFVxM
S2AS1aAnpIBuD8m/CSBkglVawshbeN1AaC3aeAXziuajAnI50ywcGWoYXoXLqdIvu03oZADoU2Ji
mYqvELw2ITiCOfq5IYME1KKh94HGU9evAgmcbUkmKkVQECPr2St9D6tPIDScf3sPzLgZRRrS/aw9
hCPpM/HfT/dd5eQpgTyuYbxseRYhKH79f9jrCUewsu022fCtKD7PxNd0c5bBTiRpVnaPFVWhSi4t
A3YaS42iH6MoFm/nT32dkaaN+Rjmk8FVzJDo0yxzFC2dVRWMjWQKb5rv1tliDEThRCsl3ID6grIm
V7/Mz5/J6Vsh1nvSJnzso8+f4Qc9ZORG16kYSWcjbqTsY0m2Z5b2vOMTierWdkp0F1f9HFCQh+zg
4c+qy5vi7OXToSFFXk42PWCtJaB5pxShuy8K5WDZfqX8T5zxXtzWhfaw94wXwN4dXY+wEb2IJMMH
TqzLFj8tc7ZxHNJI4SEEbWyggWbfHGlWiscPNbm9XTIgv9+yYyOZi+LM2MPAIuta3CudVhB5qRlD
MmevWivcbQn8pDkt5HX+k+IhhzV6bjO5cQz912K+sx1APcx/Jjeq6st/HCiWVbIJh3lVR1zU3qM8
SSugvMy/F2ehBNWpJq8MhAqIF10rdPFU9cyoafVoaNUJkKIee4B6fz+wPOTscqYbH8hkZ60ZaC47
wLs6IEFhiLWZ4pjA6fsTMocTQ7wXZa6X7h2mSJ2qvH2AiyKUjgh9xIjNhXllXfh2JBJqn5Azq5W4
ZnettFzcmqQWDNaxnOEobEcqqhjorvGSz8HEUFn69VwhJzCHjq6B4BrW8k6/12vt3Fo9zhxz9Jwu
26ru/oUfn+XCjjd7Yb0whGnm51Ol4HBFZYgaf8k8m3kojusRG2Zp8pYdWt32lXCVkNuK5j+u+Q37
cdvTZLBjcop+VNJfYVTGTk1lazz1oOcl8SRqMTTLcIZ/GFc7Yex/8hz9t9QhseIeifBob1dfKgCy
B1Ge6jCT5kx6dPsf4ONQCg2Ei+8fV5ctho0hdVBiYZbpMkjuWjXNZ5bsnDcKY/CTXUoBZ+GRZPXZ
rY2FdNxWCsoVz7fgpJ4IoHbZFchNBLOOpdJK32pTnpsTtfi9z3devljEsxucbXm2jaseXfZbcVAI
V7Zb8/ly74UklgcwKVpbouJnfqVsou5HLe7Ival/ps39KlQK9kQkd5+b0aEDznlQbBOYGS9aggk+
4bkc5ayNImvRQxvlivAaS69L9Wupyk0FcKZLLPAi5yp2zTYmAIwkZ1H5uARKSc8J3EXKX2PFhI8r
e8mdXpcjeTwI4MTQYm/aqvRSUMjPGvYJHhaMW/jWOtMkFt1SFaN4DM3cp8HGRMs4yoSdEpZZCIeK
70/B5Kii89k+ifc5oabChuivxMVDYSHFNzU1m+gpxhrVwn/vjRZ4keNvijmo3u9PUvxgFvOOa0f0
Xt4OgttYq1FtwnT0/I3w5QsGhCOyQNcrd+K0zrYGkMuLL4Lv5GLZgTkIG2UuC64jWdo9z4NxVOjR
t/gTaNjsWJTgsa9wFv8xdZt6J2WPdyDaJO5Yf3K6HPXquTo2J0GlQNeSp9o77qTn1d7PHnKCLQZ6
D8GTh/ChJhPNWC3f3rnoZk0eCDcge3Dj5HBrq8g0f0HoIi1T5NwWveZ0IBHSGLVrpGFprBUmpPOn
TCnh/k/elRTcdHneln6MoKlrUxumPXE5HhNCalwjotstfPdbcIKgxg==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
