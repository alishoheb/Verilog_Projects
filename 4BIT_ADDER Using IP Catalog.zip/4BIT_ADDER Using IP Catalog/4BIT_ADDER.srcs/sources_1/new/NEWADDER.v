`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/06/2026 10:46:54 PM
// Design Name: 
// Module Name: NEWADDER
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module NEWADDER(
    input [3:0] A, B,
    input CK,
    output [3:0] S,
    output COUT
    );
    ADDER ADDER_4BIT (
        .A(A),         // input wire [3 : 0] A
        .B(B),         // input wire [3 : 0] B
        .CLK(CK),      // input wire CLK
        .C_OUT(COUT),  // output wire C_OUT
        .S(S)          // output wire [3 : 0] S
    );
endmodule