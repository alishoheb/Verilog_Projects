module STIMULI(


    );
    
    reg [3:0] A,B;
    reg CK;
    
    wire cout;
    wire [3:0] sum;
    
    NEWADDER dut(A,B,CK,sum,cout);
    
    always 
    begin
    #10 CK = 0;
    #10 CK = 1;
    
    end 
    initial
    begin
    CK = 0;        // Initialize clock to prevent X state
    A = 3; B = 6;
    #10  A = 3; B = 6;
    #10  A = 4; B = 6;
    #10  A = 2; B = 5;
    #10  A = 9; B = 4;
    #30  $finish;  // Stops the simulation from running forever
    
    end
endmodule