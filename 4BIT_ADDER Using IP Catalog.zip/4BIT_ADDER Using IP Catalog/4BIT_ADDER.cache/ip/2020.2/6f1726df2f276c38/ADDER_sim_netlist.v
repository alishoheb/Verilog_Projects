// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Nov  6 22:50:40 2026
// Host        : DESKTOP-M777NEE running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ ADDER_sim_netlist.v
// Design      : ADDER
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "ADDER,c_addsub_v12_0_14,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "c_addsub_v12_0_14,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (A,
    B,
    CLK,
    C_OUT,
    S);
  (* x_interface_info = "xilinx.com:signal:data:1.0 a_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME a_intf, LAYERED_METADATA undef" *) input [3:0]A;
  (* x_interface_info = "xilinx.com:signal:data:1.0 b_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME b_intf, LAYERED_METADATA undef" *) input [3:0]B;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk_intf CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk_intf, ASSOCIATED_BUSIF s_intf:c_out_intf:sinit_intf:sset_intf:bypass_intf:c_in_intf:add_intf:b_intf:a_intf, ASSOCIATED_RESET SCLR, ASSOCIATED_CLKEN CE, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.000, INSERT_VIP 0" *) input CLK;
  (* x_interface_info = "xilinx.com:signal:data:1.0 c_out_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME c_out_intf, LAYERED_METADATA undef" *) output C_OUT;
  (* x_interface_info = "xilinx.com:signal:data:1.0 s_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME s_intf, LAYERED_METADATA undef" *) output [3:0]S;

  wire [3:0]A;
  wire [3:0]B;
  wire CLK;
  wire C_OUT;
  wire [3:0]S;

  (* C_AINIT_VAL = "0" *) 
  (* C_BORROW_LOW = "1" *) 
  (* C_CE_OVERRIDES_BYPASS = "1" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "0" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_SINIT = "0" *) 
  (* C_HAS_SSET = "0" *) 
  (* C_IMPLEMENTATION = "0" *) 
  (* C_SCLR_OVERRIDES_SSET = "1" *) 
  (* C_SINIT_VAL = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* c_a_type = "1" *) 
  (* c_a_width = "4" *) 
  (* c_add_mode = "0" *) 
  (* c_b_constant = "0" *) 
  (* c_b_type = "1" *) 
  (* c_b_value = "0000" *) 
  (* c_b_width = "4" *) 
  (* c_bypass_low = "0" *) 
  (* c_has_bypass = "0" *) 
  (* c_has_c_in = "0" *) 
  (* c_has_c_out = "1" *) 
  (* c_latency = "1" *) 
  (* c_out_width = "4" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_c_addsub_v12_0_14 U0
       (.A(A),
        .ADD(1'b1),
        .B(B),
        .BYPASS(1'b0),
        .CE(1'b1),
        .CLK(CLK),
        .C_IN(1'b0),
        .C_OUT(C_OUT),
        .S(S),
        .SCLR(1'b0),
        .SINIT(1'b0),
        .SSET(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
R+TTV2BAhe9Ek8IveLCAIK+vyB2qa4TorazWyGCbrxCKkVhTBvAD6RqPeP/JqtRuh2zDPzraR9rT
gUyNSWD83A==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
XM2mYTm+gCT0AhW4S5p7IlzH34WHm/fa2tLSENK5xQp44huwLBqk+dBcYbe4GM+6wqA3pzoUNE9T
SluI3P6DpsOt14ispiaJSciB+VdlU+Q0e63sKyfq++TGO3CTW5OhLIxojUbYrTbdY4WbGkk4yG0Y
qGwauBBx1uBueCA2GC4=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
M9U+BjMD5E96pT2zTDB1OSiHn8IS+G+aDNa3MIF/jeClLSPAOJwufjuzRcyAtwx0354Pb7AaFOwR
6CcoWPQM1dcUC6avyG/0PRrtZP/KpXS3/9PiWsaFHPYVLfqBMCUDoraXwfpfMxmOy8hD0iI6TtWc
j1xJUXVsbv+kqOeTUloYmwdRx/8cs46FvZfnFpiZXMFMsTsT9zvmCyNxiZefgFKT064BWsCkg2fa
W2IXperFJQzpE9mXVwGSjl6xDUp55esPyEPcDI4xy0T+q2KtBQj2Qn2DJRZ8DKAvjXNQmo/tbweh
l+RGgbFge035kxDZ/t5pFweR/SYowAMdG2yOwA==

`pragma protect key_keyowner="ATRENTA", key_keyname="ATR-SG-2015-RSA-3", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
absLoVdCG0/WeiZ9M4NtAUjz+XnLze4vahkoVw40DL65GHoB/ikdBh+LyLQ7V3LckxaJp7Ihe1ow
2yXZZfuygvynBc+n/CI1EDwjo64cUTgVLg6gqySahs3D5Xkp8kFBBxARQmdoErJqqhefej6SXrxx
13OxNfq4vRGx7YG4l2M61gUhVtUX9poQdq5dxitmrLXD1kpdnUsj/YIpVBaLv/TBn9G44WiyRNIK
ojx9q2JyYKiWBfcBh+fpJV9PudrBUPMu8kvWsRizFr+r8Ya09D3o9iJUZ6FWOBiFsidvZNgmp1u/
nv56cp+qpaTesLtwmKiZbrhQtq6YXQvzPpDQXQ==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
t2oJ825g01R4DfbjT3g+VDPmL9PAyVC2t8Ozl94Xb2xucD77bNiPcvutyZFkA0lqWfRMp8Z3kkTE
OOo/FpGS3c1SP04/jMKLZD9E7DL6iVBRfxa3itPHxsSD0RAP4yPHw3yCiIsmB0q25x8+so3h/QOv
DKZh98m5ku9UnG+pY6c=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
koDeaCPE+GNu9rMKu+nnX8UvNKbOa7mKCRwRUXCmZNo0yL7JuxnKQiStr89+6Ws9bOIbY8P6XKLC
WoSokcQl2MIZuh7gUJ+LQSPTB9HIkHPuGGPibAaiYY3e/6TBvv0+QG5gTvuf18Nz0UQyxRzNBFY7
2e0fNw+zoh4XJubbVaqqBBqTNyIM/naqx2G+DBhvJF/RlcpsJUe2eVt+uttis5ukRD1ndenp7rvA
+Ub6MDtoxunfFJsXEQ8QZkuZiT5XfcmJdkquGywSafJqKksYNJZpGleQnak/ePqKq8cYIbfpqOo1
MlqTFX2khe/WU/cqsW+5jXmRAgWueTOvg5hW2A==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
wZaMVki09KtetQFaQKbOEpc8bkgxHSc8zyuzh+dwZ44uN2hbx3K7ITnC8dDkn3EMZGwk7C0u4eBt
eru14n5jQ1LfuUg4cKuwRNAgFxc7GaymqPYSRK9OQZHWZ+w6Alh4X9YWb6UVcsv4sCJA8YT9QeZ2
8PJYA3L+OY2t8Dcx3JcdLeVgMWDrP/zfpXyfMdPpwgBSSCqJHFsYdlG06onoQq2DDJ/SpC0W2oHU
JJAOTss7Cf3giWx2XTrorU5k4KbClTaEv4QAsogatkMf+oa9OfJQg5b7OUNbNqSzTV2IvRXtKIBC
N3mFkAtau93JXZzbow8bF+Y708RmUyIR5AX9og==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2020_08", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
gidhQdKtgCKZpycO58SKONz/x64JxoYiDvm7CY7FhAgR8N3zqVR49qh/d9ImLGjAjXhz9ISSvhiE
1TpzIsqbVIoSEHhHCsw8fW3eNfjSKG9+5c0qMghoZBwnf9txWcso6wczPV8wSYfFgOnId+/H4w2u
MtSdrp2j2HeGCN7hmduXDeRIcLF+ekxNNZVk0wscD3yxYdFDWscebLgM1N+Cx8uwWvloVVe1fNSl
IBecuxue/tBnCdqw10D1fC8gGorhdNUhO2bTYqZL/+voIIAXkux7Z0BGx6B2uSJYuZ0j2LS23yyk
r0QDrL3YOpbEPBbFhTy9LQz59rkITBRhVeBqVg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Lv7TtlI9EkMH+4ifu40NSGcF5VLP+fQr0uBXzvHjgpvggoEPEBlbTyXFtewlIbLNuHO4GjqSxFa3
oGjcKGgjJ4JKEHh9NZ/42sDCCnN1TS1zrfhPhpg3aJ3aGsOq5GxB6oAuNGvsTC7HgKk9lvgZfAiC
9ubfhd8fCUCrbS2jYuGLkpNxtwRxEbxLfMa6l2yusSJt8g6sfH0aGGBJWZjKnUZ1SyA1DmzZW3ox
o1AE17uwesEX5+JGPaqlsN+jLpbHhpv24GF4NS806LjJrXOO9qXbZScc78Z/R2xMBhLYAC0AHR8o
o8hlz9kYq3NSGSCdEMOcxNjVxDMYBrdZ+Lc+ag==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 2464)
`pragma protect data_block
l/KhO8Fi6xMMwKA9b8fijgmU9XDtLYXqy0CTH/H6T2egDu92jNvGNmFCmrIoMNiE7Qt9Tn3gXfUJ
/7qINJPE5aAHBbbWLBjy++BMOdBdOTqgkNiEaeBMEkblXMosI5DAGS6w7/QtefjueGHEwBsnl7vy
CuQkSkDLknDzRDRVxfEUleAwgDpwBURvTUOR8EjtqCLgDj3DZFnKwTLNZaNjEvaKeL1K3xQrr5Y4
2Zc1Q207WXqoTHehO3b1TBiYXW6Ts/IIKCYUl2diiNwgN29mIMGKy5ajlmYihnI7FTj3mz9RSXlb
jB4hmjDynWf+xtvelK6l8iZRUFMnfmisBqoWirDQ4oJjZN7Tqfd9ReVlxpqsfLa/3B4HGRXCLsUu
8h9U5EZzNTjPC46G6L/fd6T+DsB8hHYkmDkAGoN2fCJb53f7o+eHOA4/JfSH2YQMg7mLPP2rk2Yu
sLbFGFp9aivkOpxgUb5a3RQcaSbxnTrf5uUPJoGYQYV7xf2Duqcxcedfnw+n5UO4s2DMz5yJvCDD
07YUGAaK4H4+2IswV9zB7TmbjVAyIF3FnwCKSEf94PUlltt+I80Gd4xP9kcLxl34VMi2wg/Gv6Hd
eWIYf8nrAHbruH01deh8kPqok7CdpIxRqc9fT27LSf2fBc+I0QJmm4PwFkqOJwnKeYQ0c8qXFXig
kpJ9YVxdVnE1gZeI8ZUtRKgoLPfgGdQ9VK2XgY9TTzf4siSsSeFidU7jL6dyN/TFU2ifu2zyFMmC
WvL8r7U4Ovfh6iYtr0dwHRbQxCxDI2W9NcK0zWy/6OOIBHKguARLoILj1nlorb4ASn90SYDeZCXp
TEvgaei035zQkz6Hv10u456Iok1gu/+jw0tn0xM04wTCgGmOnvYxnutCRGafsdeYc3LG5j+Jm2PS
140mtdPiVYL/EW9ToRZnVvyMNoQAEvjuCEp7pft7F5LPn5fPemT4lDT/Eo0E+N2fApYRjDcIByt7
xvRe1a3jo6vZmRaEwZmBbfCrKnTbTi6zRzdKInYABlr+l9q5izzLFEqRbex97iDnI3xMOg0EPkOn
JarjxYqgS6Mn8kdtdfjUYl9olgTQ+Z2JzN9Y1VXJS4OSf14+FpVwOmHd96C+FURyItx4bsc93pEs
c1sTHNYMIqQaxyUnvqMW4XTJomAt7fMIjxPEXgAfjRH6Xi23mPZXoKr7fOPLZV+qGnxTMZJavIWN
yZ01QpnJkAyET19ikmQolcJ6+QgW5cbC5pXNRUDuktkbNJIW/nSpy2L1j9OMuvQZM087IIkZ1Wg1
Mo+L2afSBsgc+mI5spjDMkqVJZD6OJRyu/5blKxl7pG+rol/kGVuwjOTI0asMx8+cPlTnYz+NU0e
08vnLGDDNJLDUHhS6E80A2cgxzx35fxTQIXPb2ysJJ3kaPhPyCABWxtZCprmh/CUVo9FVrv7PcU9
876VpMFs7/Uv+SPncX1Qae1wvIg3aDlSg4DDo0CcRWvMOc0jHAu2CCKzh1MdvXoPiQgC4I2zF0cn
0YUC9QT7ICZ1tqZrW9Z3xpyWgzPX6lNG0QuqArrjAkiTIj8JmNdpyDwtEeQS4AWQgNzOk3+sbhTv
MzaS2GaDSZxCkruoMwp/MBdQVC3bjtRlpREWrO6YhLSFh844eUifVlAhpFawajPvIGjCD3qPvgbW
EPWd3wA9Tp2+aPdL5JbqzgB2Kk1XycDDhshyj9Bsso2NZjAWzDNuvB/ICAlIfP9HOgv9EwmGVJgN
Aga1TzdZitpRrr2ihA0nPY+0S9TMUOrkktM/xcUmkUYRpGYIOQVqVr+nDiUhNIkWjGBgw6doR4Qp
DToa0p5Pqql8th3hauU6xFDLWinZmCD33DT7qSV6ap098yFhZu/FpqN7aL5XbnQCbz4p+RVFZIWJ
UkXWeMvaPOPNyAcf07IJsNBxxVsSDjQBadEpd+e6Iq7AUhxPMa4tA5j8kptxmp1cYQ0Ra19UiO2U
LE/wyBUfRf4fWcPUEz28+qkMQrl+VVfamAsMBMO18lGtDnLjqHfk2CAABEjdUVKV2sWD/ru6IMF4
mJ1e8cKv+XRY8WLJUW8t5vsOyXGxcFkh0/jh9WXME+ZZqJJ0Uwlp4/mN4/Kw/lFuq6iq3PeoabqM
rAT2DKTWWE2S3afgDhJdkBSsPXwY21D22g+tEeBTP4MFlWdA7Xl5ciIGd7YHn8vuB+LauuwMt3sX
JokJjwfbtdZMTTsVutbpAplT/vSJi5WHmeitv/MHeGq+ZLaEaahw3e+Y3SR77iXo94qxFLCUGAur
YjOWE87ius7dMphDriqsL913dUuunU7PjfrFN/Z7Q+AzKpUFL8tbozPJ0Q1RvklKM9udvCnyOIlh
t2r9SdhyhnoRfueSzSDV3FDuUk0vfMKCJ4AwSBvLozNj8HH1SJvSlTD7Ht6XTEvkI3O6auKhRcNx
c1tGs3FLMjTGcg8vJdOmxiyUVIAMFBVGKydRJWCMRl16fpCAriFhq5w+uhSjiYYwZVQ6ukn3c3A1
v3oD4sky/lrBB+6gH61zdNM00AAnA4VFGBd9xGndfWuBk7IA0uzJ3dWj11BIJgfXLDLv+fv5klkj
Z9cYpamYotWlhGS6shNigqkmzO7BuzmYsVWgFT/KS14YLSwXkdYbvmoVmjw2lcgHO/Zy5MgdNFZ9
KFsnGhEt5NOkfES0Rg60nyVhCvemXDwd1B1a/cpZ/BesO0hlvjKLkVfzVhVRenRJJonz5Gf/Z0iM
13Yu9G16P7/XIzHhojYq3mg0hEwant7V3j28VTR47/iclByZsUi4NrEIerBLhcKAh4xM2b/cx4Rx
lL7zb0Nt5dROIsp4QvN/OgjmGgO1U30mQjLI3IvpxIhyN+1yjSpsQR3tBBHvXGRhfZR/AsZPOPh7
7TqM4mkxf3dOstcqBvLqZflYXaDfEPvxmnE+TNt42mDyEzAb6JxTytSqfjl6roTT7AMr1MFXtAIC
BfqTZg5VAgwoLUgwHAESOKDNSEq/4Pb2A6m5fGvVLfr6CI5CXd9TskvafNIIIg5CF6VILqzEROud
RylXi5icEcjyQVy5orML9VogHluQ7WS27jo7PtP36UlT93UvJdjHXn7YmjW2qBSaP3m/leJ2qyrV
3jcQN5NCDyFLxQPJxVjYPOtyLn3dof6pgWtLtRYWVgp0pSNz1+jVQJcpT6THxak70DPhWnQ5mSip
596882mToLZEdftPgHIazSGuW1S3JIkdygAzInqCYnbGxn6M66xqM08Ci8EPrOvR1Q7fxB+wAgeN
0VlDCvKD0SgzLyq7Ow==
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
R+TTV2BAhe9Ek8IveLCAIK+vyB2qa4TorazWyGCbrxCKkVhTBvAD6RqPeP/JqtRuh2zDPzraR9rT
gUyNSWD83A==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
XM2mYTm+gCT0AhW4S5p7IlzH34WHm/fa2tLSENK5xQp44huwLBqk+dBcYbe4GM+6wqA3pzoUNE9T
SluI3P6DpsOt14ispiaJSciB+VdlU+Q0e63sKyfq++TGO3CTW5OhLIxojUbYrTbdY4WbGkk4yG0Y
qGwauBBx1uBueCA2GC4=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
M9U+BjMD5E96pT2zTDB1OSiHn8IS+G+aDNa3MIF/jeClLSPAOJwufjuzRcyAtwx0354Pb7AaFOwR
6CcoWPQM1dcUC6avyG/0PRrtZP/KpXS3/9PiWsaFHPYVLfqBMCUDoraXwfpfMxmOy8hD0iI6TtWc
j1xJUXVsbv+kqOeTUloYmwdRx/8cs46FvZfnFpiZXMFMsTsT9zvmCyNxiZefgFKT064BWsCkg2fa
W2IXperFJQzpE9mXVwGSjl6xDUp55esPyEPcDI4xy0T+q2KtBQj2Qn2DJRZ8DKAvjXNQmo/tbweh
l+RGgbFge035kxDZ/t5pFweR/SYowAMdG2yOwA==

`pragma protect key_keyowner="ATRENTA", key_keyname="ATR-SG-2015-RSA-3", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
absLoVdCG0/WeiZ9M4NtAUjz+XnLze4vahkoVw40DL65GHoB/ikdBh+LyLQ7V3LckxaJp7Ihe1ow
2yXZZfuygvynBc+n/CI1EDwjo64cUTgVLg6gqySahs3D5Xkp8kFBBxARQmdoErJqqhefej6SXrxx
13OxNfq4vRGx7YG4l2M61gUhVtUX9poQdq5dxitmrLXD1kpdnUsj/YIpVBaLv/TBn9G44WiyRNIK
ojx9q2JyYKiWBfcBh+fpJV9PudrBUPMu8kvWsRizFr+r8Ya09D3o9iJUZ6FWOBiFsidvZNgmp1u/
nv56cp+qpaTesLtwmKiZbrhQtq6YXQvzPpDQXQ==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
t2oJ825g01R4DfbjT3g+VDPmL9PAyVC2t8Ozl94Xb2xucD77bNiPcvutyZFkA0lqWfRMp8Z3kkTE
OOo/FpGS3c1SP04/jMKLZD9E7DL6iVBRfxa3itPHxsSD0RAP4yPHw3yCiIsmB0q25x8+so3h/QOv
DKZh98m5ku9UnG+pY6c=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
koDeaCPE+GNu9rMKu+nnX8UvNKbOa7mKCRwRUXCmZNo0yL7JuxnKQiStr89+6Ws9bOIbY8P6XKLC
WoSokcQl2MIZuh7gUJ+LQSPTB9HIkHPuGGPibAaiYY3e/6TBvv0+QG5gTvuf18Nz0UQyxRzNBFY7
2e0fNw+zoh4XJubbVaqqBBqTNyIM/naqx2G+DBhvJF/RlcpsJUe2eVt+uttis5ukRD1ndenp7rvA
+Ub6MDtoxunfFJsXEQ8QZkuZiT5XfcmJdkquGywSafJqKksYNJZpGleQnak/ePqKq8cYIbfpqOo1
MlqTFX2khe/WU/cqsW+5jXmRAgWueTOvg5hW2A==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
wZaMVki09KtetQFaQKbOEpc8bkgxHSc8zyuzh+dwZ44uN2hbx3K7ITnC8dDkn3EMZGwk7C0u4eBt
eru14n5jQ1LfuUg4cKuwRNAgFxc7GaymqPYSRK9OQZHWZ+w6Alh4X9YWb6UVcsv4sCJA8YT9QeZ2
8PJYA3L+OY2t8Dcx3JcdLeVgMWDrP/zfpXyfMdPpwgBSSCqJHFsYdlG06onoQq2DDJ/SpC0W2oHU
JJAOTss7Cf3giWx2XTrorU5k4KbClTaEv4QAsogatkMf+oa9OfJQg5b7OUNbNqSzTV2IvRXtKIBC
N3mFkAtau93JXZzbow8bF+Y708RmUyIR5AX9og==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2020_08", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
gidhQdKtgCKZpycO58SKONz/x64JxoYiDvm7CY7FhAgR8N3zqVR49qh/d9ImLGjAjXhz9ISSvhiE
1TpzIsqbVIoSEHhHCsw8fW3eNfjSKG9+5c0qMghoZBwnf9txWcso6wczPV8wSYfFgOnId+/H4w2u
MtSdrp2j2HeGCN7hmduXDeRIcLF+ekxNNZVk0wscD3yxYdFDWscebLgM1N+Cx8uwWvloVVe1fNSl
IBecuxue/tBnCdqw10D1fC8gGorhdNUhO2bTYqZL/+voIIAXkux7Z0BGx6B2uSJYuZ0j2LS23yyk
r0QDrL3YOpbEPBbFhTy9LQz59rkITBRhVeBqVg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Lv7TtlI9EkMH+4ifu40NSGcF5VLP+fQr0uBXzvHjgpvggoEPEBlbTyXFtewlIbLNuHO4GjqSxFa3
oGjcKGgjJ4JKEHh9NZ/42sDCCnN1TS1zrfhPhpg3aJ3aGsOq5GxB6oAuNGvsTC7HgKk9lvgZfAiC
9ubfhd8fCUCrbS2jYuGLkpNxtwRxEbxLfMa6l2yusSJt8g6sfH0aGGBJWZjKnUZ1SyA1DmzZW3ox
o1AE17uwesEX5+JGPaqlsN+jLpbHhpv24GF4NS806LjJrXOO9qXbZScc78Z/R2xMBhLYAC0AHR8o
o8hlz9kYq3NSGSCdEMOcxNjVxDMYBrdZ+Lc+ag==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
T8wmhBD0E7v+0nRsFtkA/6mDnZhaTgsuC9KcjZsZnY1TGE/h8RyXhNuhl+RHSp2Ry7enDAxH1ZD3
WHXmkTXjaUsKVcosoSKCN4yVYI2HHqz14cLbSZgPK8IOahUIaCI16QdWXgUmHFiXJpieSU8nRUoI
W/t6omrcT/ODWE2QWfGVFRVp+GkhP0uFksE2gQ/6hhcSrUC75wGwsF3rMTHM+ziNyRxj+6XMw/fe
A0WvF2m9/OKFwBRFZBb7jJKIBhAjHPC1At4ujy0PZF242eghu451bS7jAWtKxaf7XVOm1T3tQ+wF
t1g32Ez24b+4/AD9gF+YWjdPWlBc8aNPmevPGw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
lhE+MLrYI21HvYnoEp1fxRthveT4g2Voqn9e93TwiEDi30l/BVJf7w1YqEwx3Y7Fk3vWHkXomXXe
XImoDOXlFhWSMKkLsG83wtWzD/vLNOToK8VisRV0MEEd/ZWNGL4Gz020S1pdAOFwOkMf+toacly9
qHxoSKkkl7vnTdgdrXw92HMCOQDY24yg5MYNfqI79K08edBQWW2wlWSieiBB4FjdjcCuQuz4c4VE
AQodRuKYp1GFgD1pcnMDp8LSiBAExLKk2QNh3CTyTApgmgkWLYipQ7kYHh+sOqrp0/I4/SwyQ0Xk
BTBuy1GbZFBx2eozISVZJUGgE9ahSDcdazFsyQ==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 6112)
`pragma protect data_block
l/KhO8Fi6xMMwKA9b8fijrcVsVP48XGhQOegAset9zodKatpnx3wFHnJA1O23yIOClib8JDRbxqj
fEk2VkxuqzD6sH6AO6yCBZe61Z2LAvdEf/swXAqCp0PuRKEjKZqfHah1x3dXjEJBLVnDLA9PHKkw
ZEKyVLKgbkZike/v7KlurHsVhW9EJ90Z2n/DWyxH3PvDV3A8Ok7WMOC54oHhEz+wrlGmAYv+NqHK
JKhKLb0fw46y3/ICLJpdl+kHt52S2KtJso2uXdGQnjMxvZHLCoivYBnaR9a/wnxhVt/nxsFSx/xY
qPeBirgRFxvrWoLTz8Sz19qNdbsZZUZFGf9zTZKcON4YaaTZa92176OfxZbTTuZtxbcFJXvaOFLw
tfk6HvTkmbpH1cvTWxl8yv5bM7XFlEPO8dslJrHtwmH9QaXHIL7d4cY+iy6GfNQ7gATYnsv5WVYY
eLRGxPDI/ETmDCXuWNDSMSp26X5PnoFFPsJ9sV8UBo7JuiSWhyX3ezcKQnjNFW9Oydfx0vIHHgz+
RVw6/a9EMIiGt1xYXNlAwxpwdBP6lUVDc2voYr2/A16B0DvuhbvKW6KrVMpMnbErWBaWPGCQXBxc
P1G2fBEl3mWJs0fNpSelF/CB1gmTxWrMPhjRzVtmpZG7OA/FtAlkKkLk2yP0mH7GIjpJbvFcAUNJ
xaWrZUh5s4gJb2sCMA8IpbddCqT1QueVFaZ2iRiGqtWUyoM+PUp7d2wTGSNc4XbAbXEIDc5pa6W0
7exe0fPcmqXc4J9VBkiwR6TSumeUE8FIPzSH13BIt/LpTTJkulhXhQd1IC3U8rSXeHhCugYYLRsi
l4uSSSc+b9JMIRYowcHHFZ75vHrQKj1IyLW3lrUc2Vie9mF3h6Nwsz4RGznIl4T/Aiv3921kbawx
j/vVORu39W4m0u5xYcjYQGEcscGXoQzsT33nmWekFZXFr+Xq8DdRhnrjD57lNn2im2A4uEZIvpBl
9CLuGR/sj/Ymq8/O7Hiy168nPlyMk8zJb9M4O9gLZlCZ11S/qCV6R07v+bIH8PTRnPXJ4YSannVB
u0JKGaPOh/bKaCZR18bbN0I6R7D3S8iX7pNisfOVa5etc3BXhc3QsXexctVUw/a/0NpYH7+kPAU+
obynr+aEFKINa/Bv6GBzmDbQymDlBqxN+CeTrmYd3c7e787iFf3yRdtk2YI2Ih8DFLGbPwEGWwye
MYWHOXbQy8AHrHF3r2QG9FXoup2GMETE08fnL8QWcJSBtQqmv3EX892Dk2dmbkZHuuyfiwipWYom
izNd9j/EI/4O0/KKCaSA4roD7wumcwNEmObDICrLridkxQTX+LtDjY0K9YcqTemQfW2+jFU/JoCo
Y531a870/oHGkpGeda2dEuFH3QT6LYCpoQYAOOtO1TtcStFSgz4cnSobm4aVOTcSmLiR9+DQEo7J
bB8Wk4OTUzdOZUGNFElOMbrxwzxE10KVTx/v3Bmo6OqP3crqh+ZKkLm5/QlHrB6Tc9OdHKeCyjFW
btuTfnE6kTss6REBcR47AkErpPZ0iGlfhs6ovNaGnGif4ioDiOpbY8blJuql6eYQk5AkkR8BcnvT
nUXU2BiMfDHQEgk0cOeNavvuVi/suA1bNK3Oa/EGM6GSiqOMsoQ6GMCAjfGPJKZeYpfsR9VwP9+m
0yLy5AyvOZ3A7vyAV2jUqLC93tFkofjU9qzi6dvTGaGc/0eRrYv4oC0QAiVuWgSgo4mf1gFIO1/i
siAQyb8qbEBoYIU1Yzul5RQWCgQ+2I0I8fZSbgsxQtiNYmOr5SvSpN6WblsPsj6RJ5ODK3jTSsmz
PIRKTEUc74JjHlTEqpg0bkY5WESh1s0zwnn0o6BOda2DM6pgxXkdq2tdzrKBa9GkgMXgnApn63SA
hesowiXReD7eqQhlTOZXTEG1djSaGVUA+I3Cexx8Rz9FPi06XewoyXw5Nysx+7hkBnxcLzbm42LG
WtK8fBWAKM12omJiVxPX9jc9l2ncHjs4ZoTsC38+bx9dc6DRaEUeCpDim/2Wi/lp5NmzL8adyVMP
4CS1JpUbZXWorQDuyKuGYk/jb/M5PSWEeNqqGdYjeOdvH/6wxd1eL7S7dOwOP+aSy8wgp91OBg2D
BTeya3QvT1pFIIxqdWf/ipCYWxIPYnI6QMvYHsDeQ89rusDYPstsRu7+0Dx9HFRXTo6SJatjT6vq
Qu06xBjJuXmqrHl80B0u77GswChL0z/JTbWToN5qlcBzhVlM3wxYrwf4obJ4/WmC/DbSDCCBoKXK
aPrD+z4HseHbOjw6L5IJm/TGlBSuP0j5oR95erZ+hUQclbkjMYgi4VdXzZeB65haC58gbLvQcWnG
2+tva3hMb16PGikixYBFie0WcLk2lb4MscAIz5hZdH9wNMVKO5Xjyjv4uXz1EtgpwPXa+42cB2y9
rB46z3+UMt7ZoTmEYo4OL2bxhxcUQNwIaMSOmjij3XZ717VO02esdFl2X5m/6qSCmBp6sSZFZWEt
6ObufEG5sVAuLrlRWg76xiW8VM4z3NwbrpO13LXBGrO/K9XV5nUyK1gMy90pZus5YV3Pa3kr2x1K
uHZ2+YZBVEgOBN1DQ0KmWzFWj1z+bx02R42fA0YkA+/YRSn7EU0VowYOHeAE3h58cnC34n6uG2di
gEnaeza+WNm2lnlruz8/izOKyECYVP8zuV78OjsN0MePs/mEs1FNYLwZMYTUTfMPHpJSC5l1s8Tl
3ktvrdjDEY8uOmpbKxzpR+fUituNtpjQa0UqzSyhqQnPAYKK5UfNPT/3A0RIdTrWK5kSqZ6YZIgv
qGRCl2ouadzsQkJizC0ofp17hprAJHutVytrdXBXlaQkpDk2PhekKSMzBdkVcxfl5+67MjTbr6Bb
TwX+hLLjKxYuxmgtAf3yUUpD3cG2e2Ml51VZTd+OChRmaV5HdYlB/CuBMVbOAIQN6KMik0lFOr6s
ghy28rvp/meTFEZKsM2Az0MaePuDfv5liVgYZGAR7fkjHWoaaDFT1G2cBegX9eborr+qXXAndPt2
WapK2Cl5xrX80zW5xaLIxtFZpOKonG8sJ3MC5dhJTXLS2HgcMSm+bVnjxG+tYUjW2F2sIfUcOVRY
HZ4h/e7EL5WdrGwczOP8xfxBOyG6BIVsaZGmabAse+zhDEEqaTiIzSFxv2Nv+mBEkRHgVzrud6EX
hNxumu/dNgxOCJK7oZlNbXGRScs7jVvTkVowYFqUlx+Yq1XpWNNJrudctt8xnTVvN92LoQmqW41A
sPlzyaF4qvdW/Mnw1fM9xbUSwcaZel9RNjFKwG/km3OW5NS1QetN/75PKHOv82pxUWBffoMqFeT3
NvnqVgvYOMVmFaZ87gl0ifZIaylUViOkSECvnVoCc/iNfDPzZPyt6Ombl081sERgmxnhDCqXDJPZ
uQ1/7K1DFJhb2pqtLDaU6M0+AGgeV2tqHT+lD3bZmK+1ZgNYYJq5JoOcLD2th/6VPQzavISO3JTm
bRsIlLVrCGhqFh2C3JUSs2MaiamXXnV+Jd/lM3hmAdZmo3vm5fH3deh8hwaI6Z6ecCa93mpnlb8k
ixOoMkccSW1GxnPtHrjn0+e3SBQvSochAIqePgGJNsuIrKHGYzS9hbSD1ZjCbddjhh9C9jlUbLum
Mf0q4dil3ASSD32f1G3mEGgzYLmMnJddm3hJ5Wo0abTSBXo3med8m9yclxfpj/5LafLA3RpMwZOI
sP3TKxeystWaqpFgrC0o4A3d5+/qL14IhJ7T+18cyV0NCFCq23W3FidGT3Yj0blNbVrqa6DRFRBm
rqDWHxZjz1IpYBlaLyCe18TxuR/zupNKDZaSdyo0VMq2trmzqi+LjDvwLufcsUTcWxOZoCpLk+L9
LVj4VJ4F4gMADi+Tl6ypaDbeTc0TD6BuWwD34oRy2Ql1jzKKm5A75zafaQ/aSBTdaZtv7UWmqS0p
KmV9ieZzyfS49xL13XvqBTAB813WWn7lc7XouQKdtuzImFJfldidSwlGXMkzOXZ9NpuMHGaf8psG
GNb720EG1iG8IQsWlaYe5YuFCEil7V6/9fn54SALy+hzKaWVDgkON/fHuuVAhf5SgjkMOHqrr9ER
Purzvtytv19j96LJm5fxA5fIU1BmA22Qy9kOKxbrfXjsKR2Fr6JyQ20KpOnQGMUOmr/RGcZt6Ojc
bcSUsauOQwWk2JnMoE1SnSTMrwhFldWmCO5Z0dcdttYGDYcQGYuHUqxi2aIWSLlG45trO7X7L/Zi
RQz0hmvEoM41RmNO8kBNJ4mAnMNG62SNkr08hp2XeYyRxopLIXvmbda8q4NSsJniJ5WYPym6F4Ax
cl3vAdvtOTx0ydkvUpVwRYHefE60XrM6JffYxY76CCKc0/rYzGcWX7Kqpb9ILtcyIW1FX0Exd2jz
1pa9sgvHieZOuQOaUqLRQDN+KYJ7HL2yAFcPAJX0720+CWrgOwq2dy7OoCGS3VcW2zyfqaTlZdg9
dzELqmlwbMZ8JcfOZswMACQ1t2zS5JTKpoTw9+6mh/pT/spG08Ppz+5Q4yyE9/WDZnCJpvcEyyNr
wKby+cmuI9HRVupW/wJRTLkbKt5D9dQwq94iofhOnfBAs+nmBrdkAWvZsUbHPUgz2yXNgU++B5d8
nn+3YOB8XqIAbtQC9KtYS4WoXsNnYuE2m3XZfE3YtFNoj1y1yLF9qdNDy1ToTonx2A5gvB5FHzj0
x+sz6WKI4SvhTVCssG67TnnuZoox9pY1D1U+eszjBfdp60ciJxHpVrsCTAkzaUI4StgcavCCjC8B
HJAb8mTy+hxrY6dg2tHOZc1G7vcbsjEEF2H7pFpptYX5kUcImqhVJnOUzsDDOy1RKXyHLWGmBvYg
oH2ecnMix3gsCW87dHpURRMZMGZLC1OTDkeNf3Lgr/jpxagzOhLUy8MDdb50DOLpPNWrE4EDRVtA
/eawn7BUPW32D8DuVCFsnA1EzLFG0V3INl+7wth974/nDd6I7sgNJM/7yH0788R5Aq5+cAILFrgw
Hztihg5xCFrBJkfmT2qYpLAHqta5bGf1E48FURd6NmrzMJwkXk35Y+5AOQVx4H2m8HXcmUntOZhB
l5Oun+9nO2OHCnRIAvI/fX4cBuoNTW6Pomg/sQSCz20r4cJ3ZW0CiSQj0/u33yLMQLxNml6+J3PO
W4na3NUL9f9xuHMZwNrqHxJ3W2GVtupjyUlWmvAqK1cYVc3ZaEoH78grKL0Sl0QkPEgjd14HSRpE
0DD1ZMCkIOfUp87If23equqdEcR9N3gVRLGJIEODcTdTE0A5wvx+Fw0qXQ8zbrVz5Z+pLzQ11oSr
BIWQNV+bV29arStMAYlYPc6Gunk1djnhuyQKDJNTr8LpHrIVaXH31k3hwq35TRzAbjKzYDdFdU+3
gkIPYWjzbtDaJ/25N9OFIiDRbwR9MTBTX+xAW/Sy4O6cB7I9HERZKd8h3cOyM8Z8GXuwE87qyd2y
/i/ZYoDW+r92q4+YLnUeJx2SJxmEqMKCNCENULE32F43Sw1AsrzqQclR09CHQIkqFI9Mic+U36PA
N2uKRc2Gc9FdEIr7eNkL/8IAKlKjdOW+H8kdZWrbpTYz0tuWE0ERnvCubj83BF6PsXt7fmy1DCw/
1DZKwWkJKupbdnbNPE5bEacYOI0MMO63luiT/77YtZ6jiiR04eDXRHTigQ+T0wjwWyAfXs7raSXj
rf+kB8rxtQBqSfnjheiK4DJw0BPvyrq1vFVoqdha25Zo2HFrK59nO2P2yz4VHKE6WSl1ATByXdSm
ELLOUgtRe2lEedTjXbtOXghXJRw9vi+yGn3yx2R/gjATzvZ42MLFuTYSY+V6ajSA0rQSCLUtOATg
va+CY9dOqRsADNa6Y4HLMs72xPwyU7z4jYzpt3h4v09d+EIJIihDRG/Vkj8zj4PjrbGgb58MEz1L
WR9xFdUQRdR/BrrE9064EIqh/7kMj1812kzsFhRFbxEPTGLJH4wBHNeits/u6VELLXQf+/3KZsGq
BCd7ea22dlutqos8PxFo2cF806Q6rL+u2BNFE4x6QpH96BpHUKupNKRHLVgSPjXbJ7tmucC02j4B
KfqGhNJaVDTZr8kQE+or8q28ALxjn7/I9mvJw98OHLZ/SfE7M2DpNlcAnvS3EKB2lVdvMO6XLb6A
3XuAiR9NSUpCDuP5wc7GDs8y0iiBGSlvzp+RRtUA09bcUQ5X4LhrZCxPr15rEsba8L7vz+yWtgU4
L+l6loOC3Swsufx1IhumqtiOl1N2M2AyWJrm9aHG1o9lns/N5xBOgcHOVhkuuuR+xuEm7Hff0I6i
FAErBF0BnRdoLwoAnqyqFHjB6fgvh4xEXOjCt2MtAp2S+eiTzC2j0POsSMxtQDxdb/fMs/hkusQW
+QGXf3hOYykUoMgBxnEs5Zq4NL3Xj7jKJ+Em7UhjwdZUhuuZIZzvjDDgRn04Ck7rXsvbfHU0QUm4
HLACIA6T7chRQ5ZTUmDxCcFw7JhlRD6SXEcHhsvOUONoI1rWJjsKtnwTv1aVFNfpgyYwDxP4wPyh
O9/4RueWh1B5FEFRa7MSVe3kkFkBHUhJo1r9V3wjomtrBnh8YHaCVp7y58p7nYbMIonOZB3jwd91
lUnaPr/5OJItjDtah8aL98zvyLWIpI2XkmlgFl8DrlbtrZsSibtBXVNVdrAiWQCV3jHIpd8KM6hL
0New9QFgMsGbnqLOkfUg+zqo9atgjyL1WLda0TBHamucB4xW6PsffOyQEy68jxFAg8erRym1ctXk
YTjoB8QVDh+tLbiLuIRwqLfg/c2WsOaT4U5yYifCRywx8YMowG1FTw3noLKfU4b5Hf9gxHkFvMww
EcWCrqylDPyYHF0gaupoOQGox016CsuhGoUmzQm/qM1LSZq9ROMfDYYQYQ57xirqNLKbT4MqwSk/
YKt8GR7UF/wFeUdCNf4yGCfndQ6grH86uz4+oFvlVpgoGhATkvsL7QntBgG77a1DfvvX66B+bxLo
8YAoEkSRmu0xPgDfMbMCLK8vW7wDkNB76UnqFPkkrRQHCycV+Mox7cdi30/JeV/WbR2dVnBetb5k
QeALnyCma5J6itNfwImFORYZrp42R6WjZzxcwsROTOQXaCwdqeGIcexxpzZ4vG39wqyc3JaCn8am
cb3hb4j7e9qNjIJv7nbmfmuhkQ932VIvScam9pliVKS0Dh+7oAICTrUX1KtYM4wKyJNzMju1lOAy
sg1smzc5agDHW61NfThZmLdWz/lRrzG7DfyGv1hIn89fMGgeK43qjd2R+CqDc2masu1P9TaEh4Iq
7jOsdOt9/kLWiIS+6i7rwadskh3MdSVvv4jrmO54AOsd5IQoHyDAuEGpHkcwJ2ezUJSoDbHKrGu1
8yKJJJEnzCxYLYE+Apv/9jKf784+G2OxgLiaiIo9QX3Fe7LCb9eYXSQN19RRz9C2eJu2buEdUo1N
k9Pe/74XfK2/l+jOPp6oZJazh9Z9i0DANb5hrIaDsOJ3Th+EJoMksaFsR8qesV8AjdUZTw7Fu2jM
iGvEYdFoGJlIX5VCSG0xqOGmKRQ4R1HA3V346r0TFItiKpjVMu21WhSfs6qBe6tyoVkzjGW6RrKf
Uy4nOx2c5ZlEpmlLNtFq8HN8A5G79TFC44SR3Acz7G1dRsWYbdyRxrXpAZPfrf8mZ2aJKG1CTPu5
LMv3yKAlcBsGjHmaf+2NKUG9COwtLliOYSuzSl8E5FZ815V5cs9ME4P+ZMhGfAI6SwoQg5kE5HFp
YFsnfu2GLnnLGC69k6AbYuc6QTVbX634Z1tJZtYfLvPJblgpLxwlgNrDqUQ7WGJj9x1wsBL1VsLw
JQVhmiSdcOPopK/fv8oC/bhpa568OnLkiDnrVcxuTgqKNR2ZwBtvVjMGTIhG2e73Hvo/S8BiWVEY
e9ON1gIttIETWo+IbaRDwZRR7rshRyPvmvimf0R8BLKFHgkFGKCY+45K/GGvNOPHPis4J+npZVS0
dyR7/tqlctX5KuRJZooOVWtb5PclQXgX91NIL44IwOd7dnaYvBLsT1K5nD6iQdjswrs/jIz+uY30
npCUz2krt7OXB4i7vNbTRvQOFnWgWO7YSrd+Np1UxaxrYJVuoQzl/1oNlZfrOk6yvWuAui/BF5KZ
S/9apoRp9KTB6YOpcQ==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
